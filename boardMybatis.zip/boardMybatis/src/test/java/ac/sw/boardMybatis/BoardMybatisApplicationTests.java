package ac.sw.boardMybatis;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BoardMybatisApplicationTests {

	@Test
	void contextLoads() {
	}

}
