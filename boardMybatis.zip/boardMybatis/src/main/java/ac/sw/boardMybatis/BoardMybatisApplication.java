package ac.sw.boardMybatis;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BoardMybatisApplication {

	public static void main(String[] args) {
		SpringApplication.run(BoardMybatisApplication.class, args);
	}

}
