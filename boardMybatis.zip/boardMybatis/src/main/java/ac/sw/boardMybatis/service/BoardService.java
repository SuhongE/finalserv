package ac.sw.boardMybatis.service;

import ac.sw.boardMybatis.mapper.BoardMapper;
import ac.sw.boardMybatis.model.Board;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;

@Service
public class BoardService {
    @Autowired BoardMapper boardMapper;
    @Autowired FileUploadService fileUploadService;

    public List<Board> getAllList() {
        List<Board> list = boardMapper.getAllList();
        return list;
    }

    public void save(Board board, MultipartFile image) throws IOException {
        // 이미지 저장과정
        String image_path = fileUploadService.storeImage(image);
        board.setImage_path(image_path); // /files/2025/11/uuidadfasfasdasdfsd.jpg
        board.setImage_original_name(image.getOriginalFilename());
        boardMapper.save(board);
    }

    public Board getBoardById(int id) {
        boardMapper.increaseViews(id); // 조회수 증가 수행
        Board board = boardMapper.getBoardById(id);
        System.out.println("ImageName:"+board.getImage_path());
        return board;
    }
}
