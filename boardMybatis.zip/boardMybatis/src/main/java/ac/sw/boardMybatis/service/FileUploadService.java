package ac.sw.boardMybatis.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.util.Locale;
import java.util.UUID;

@Service
public class FileUploadService {

    @Value("${file.upload.dir}")
    private String uploadDir; // C:/Webserver/uploads

    public String storeImage(MultipartFile image) throws IOException {
        validateImage(image); // 이미지 정상적이지 검사 => size, ....
        LocalDate now = LocalDate.now(); //
        Path dir = Paths.get(uploadDir, String.valueOf(now.getYear()), String.valueOf(now.getMonthValue()));
        Files.createDirectories(dir); // C:/Webserver/uploads/2025/11 폴더 생성
        String originalName = image.getOriginalFilename();
        String savedName = createImageFileName(originalName);
        //파일저장
        Path target = dir.resolve(savedName);  // C:/Webserver/uploads/2025/11/uuidadfasfasdasdfsd.jpg
        image.transferTo(target.toFile());
        // DB에 저장할 내용 정리
        String urlPath = "/files/" + now.getYear() + "/"+ now.getMonthValue() + "/" + savedName; // /files/2025/11/uuidadfasfasdasdfsd.jpg
        return urlPath;
    }

    public String createImageFileName(String originalName) { // 원본이미지파일 이름 => 유일한이름(UUID) 생성
        String ext="";
        if(originalName != null && originalName.contains(".")) {
            ext = originalName.substring(originalName.lastIndexOf(".")); // asdf.asdf.aa.jpg => .jpg
        }
        return UUID.randomUUID().toString().replace("-","") + ext;
    }

    public void validateImage(MultipartFile image) {
        if(image == null || image.isEmpty()) {
            throw new IllegalArgumentException("이미지 파일이 없습니다");
        }
        if(image.getSize() > 10 * 1024 * 1024) { // 10MB
            throw new IllegalArgumentException("이미지 사이즈 제한 넘었다.");
        }
    }


}
