package ac.sw.boardMybatis.model;

import lombok.Data;

import java.sql.Timestamp;

@Data //
public class Board {
    private int id;
    private String title;
    private String content;
    private Timestamp regdate;
    private int views;
    private int member_id;
    private String writer_email;
    
    // for image
    private String image_path; // UUID에 의해서 생성된 유일한 이름
    private String image_original_name; // 원래 파일 이름
}
