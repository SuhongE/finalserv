package ac.sw.boardMybatis.service;

import ac.sw.boardMybatis.mapper.MemberMapper;
import ac.sw.boardMybatis.model.Member;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service // DI위해서 ...
public class MemberService {
//    @Autowired
//    MemberDAO memberDAO;
    @Autowired
    MemberMapper memberMapper;

    public void addMember(String name, String email, String pwd, String age) {
        int intAge = Integer.parseInt(age);
//        memberMapper.addMember(name,email,pwd, intAge);
        Member member = new Member();
        member.setName(name);
        member.setEmail(email);
        member.setPwd(pwd);
        member.setAge(Integer.parseInt(age));
        memberMapper.addMember(member);
    }

    public Member findMember(String email, String pwd) {
        Member member = memberMapper.findMember(email, pwd);
        return member;
    }

    public Member findMemberByID(int id) {
//        Member member = memberDAO.findMemberById(id);
//        return member;
        return memberMapper.findMemberById(id);
    }

    public void updateMember(Member member) {
        memberMapper.updateMember(member);
    }

    public List<Member> getAllMember() {
//        List<Member> list = memberDAO.getAllMember();
//        return list;
        return memberMapper.getAllMember();
    }

    public void deleteMember(int id) {
        memberMapper.deleteMember(id);
    }
}
