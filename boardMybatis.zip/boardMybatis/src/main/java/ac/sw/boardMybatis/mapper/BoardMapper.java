package ac.sw.boardMybatis.mapper;

import ac.sw.boardMybatis.model.Board;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface BoardMapper {
    List<Board> getAllList();
    void save(@Param("board") Board board);
    Board getBoardById(@Param("id") int id);
    void increaseViews(@Param("id") int id);
}
