package ac.sw.boardMybatis.controller;

import ac.sw.boardMybatis.model.Board;
import ac.sw.boardMybatis.model.Member;
import ac.sw.boardMybatis.service.BoardService;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;

@Controller
@RequestMapping("/board") // 공용시작주소
public class BoardController {

    @Autowired
    BoardService boardService;

    @GetMapping("/list") // ===> /board/list
    public String list(Model model) {
      List<Board> list = boardService.getAllList();
      model.addAttribute("boardList", list);
      return "/board/list"; // /board/list.html
    }

    @GetMapping("/write")
    public String boardWrite() {
        return "/board/newForm"; // newForm.html
    }

    @PostMapping("/save")
    public String save(@RequestParam("title") String title,
                       @RequestParam("content") String content,
                       @RequestParam(value = "image", required = false) MultipartFile image,
                       HttpSession session) throws IOException {
        Board board = new Board();
        board.setTitle(title);
        board.setContent(content);
        Member loginedMember = (Member)session.getAttribute("login");
        board.setMember_id(loginedMember.getId());

        boardService.save(board, image);

       // return "/board/list";
        return "redirect:/board/list";
    }

    @GetMapping("/detail/{id}") // => /board/detail/1
    public String boardDetail(@PathVariable("id") int id, Model model) {
        Board board = boardService.getBoardById(id);
        model.addAttribute("board", board);
        return "/board/boardDetail";// boardDetail.html
    }
}
