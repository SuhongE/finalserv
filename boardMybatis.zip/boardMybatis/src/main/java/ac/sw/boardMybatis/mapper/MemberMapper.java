package ac.sw.boardMybatis.mapper;

import ac.sw.boardMybatis.model.Member;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface MemberMapper {
    void addMember(@Param("member") Member member);
    Member findMember(@Param("email") String email, @Param("pwd") String pwd);
    Member findMemberById(@Param("id") int id);
    void updateMember(@Param("member") Member member);
    List<Member> getAllMember();
    void deleteMember(@Param("id") int id);
}
