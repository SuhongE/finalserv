package ac.it.boardMybatis.mapper;
import ac.it.boardMybatis.DTO.Order;
import ac.it.boardMybatis.DTO.OrderItemView;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface OrderMapper {
  void insertOrder(Order order);
  void insertOrderItem(Long orderId, Integer bookId, Integer price, Integer qty);
  int getBookStock(Integer bookId);
  int decreaseStock(Integer bookId, Integer qty);
  List<Order> findByMemberId(@Param("memberId") Integer memberId);
  Order findDetail(@Param("orderId") Integer orderId, @Param("memberId") Integer memberId);

  Order findOrder(int memberId, Long orderId);
  List<OrderItemView> findOrderItems(Long orderId);
}
