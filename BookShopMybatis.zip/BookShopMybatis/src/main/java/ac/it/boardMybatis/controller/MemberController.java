package ac.it.boardMybatis.controller;

import ac.it.boardMybatis.DTO.MemberDTO;
import ac.it.boardMybatis.service.MemberService;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.List;

@Controller
public class MemberController {

    @Autowired
    MemberService memberService;

    @GetMapping("/") // http://localhost:8080/
    public String index() {
        return "index"; // index.html
    }

    @GetMapping("/signIn")
    public String signIn() {
        return "signInForm"; //signInForm.html
    }

    @GetMapping("/signUp")
    public String signUp() {
        return "signUpForm"; //signInForm.html
    }

    @PostMapping("/register")
    public String resgist(MemberDTO memberDTO) {
        System.out.println("email:"+memberDTO.getEmail());
        System.out.println("pwd:"+memberDTO.getPwd());
        System.out.println("age:"+memberDTO.getAge());

       // MemberService memberService = new MemberService();
        memberService.registNewMember(memberDTO);

      return "index";
    }

    @PostMapping("/login")
    public String login(MemberDTO memberDTO, Model model, HttpSession session) {
        System.out.println("membereDTO:"+memberDTO.getEmail());
        System.out.println("membereDTO:"+memberDTO.getPwd());
        MemberDTO member = memberService.login(memberDTO);
        if(member != null) {  // member
            session.setAttribute("loginUser",  member);
           // model.addAttribute("user",member);
            System.out.println("Welcome !! "+member.getEmail());
        } else { // not member
            System.out.println("Try to login again");
        }
        return "index";
    }

    @GetMapping("/logout")
    public String logout(HttpSession session) {
        session.invalidate();
        return "index";
    }

    @GetMapping("/memberList")
    public String memberList(Model model) {
        List<MemberDTO> list = memberService.getAllmembers();
        model.addAttribute("members", list);
        return "memberList";
    }

    // updateProfile
    @GetMapping("/updateMyProfile")
    public String updateMyProfile(HttpSession session, Model model ) {
        // get the user information from DB
        MemberDTO loginedMember = (MemberDTO) session.getAttribute("loginUser");
        MemberDTO member = memberService.findById(loginedMember.getId());
        model.addAttribute("member", member);
        return "updateMyProfile"; // updateMyprofile.html
    }

    @PostMapping("/updateMyProfile")
    public String updateMyProfile(MemberDTO dto) {
        memberService.updateMember(dto);
        return "index";
    }

    @GetMapping("/delete/{id}")
    public String deleteMember(@PathVariable("id") int id) {
        memberService.deleteMember(id);
        //return "index";
        return "redirect:/memberList";
    }
}
