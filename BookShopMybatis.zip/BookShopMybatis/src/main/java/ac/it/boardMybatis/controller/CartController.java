package ac.it.boardMybatis.controller;
import ac.it.boardMybatis.DTO.MemberDTO;
import ac.it.boardMybatis.service.CartService;
import jakarta.servlet.http.HttpSession;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller @RequiredArgsConstructor
@RequestMapping("/cart")
public class CartController {
  private final CartService cartService;

  @PostMapping("/items")
  public String add(@RequestParam Integer bookId, @RequestParam Integer qty, HttpSession session){
    MemberDTO m = (MemberDTO) session.getAttribute("loginUser");
    cartService.addItem(m.getId(), bookId, qty);
    return "redirect:/cart";
  }

  @GetMapping
  public String view(HttpSession session, Model model){
    MemberDTO m = (MemberDTO) session.getAttribute("loginUser");
    var items = cartService.listItems(m.getId());
    int sum = items.stream()
                    .mapToInt(it -> it.getLineTotal())
                     .sum();
    model.addAttribute("items", items);
    model.addAttribute("sum", sum);
    return "cart/view";
  }

  @PostMapping("/items/{id}/qty")
  public String changeQty(@PathVariable("id") Integer cartItemId, @RequestParam Integer qty){
    cartService.updateQty(cartItemId, qty);
    return "redirect:/cart";
  }

  @PostMapping("/items/{id}/delete")
  public String delete(@PathVariable("id") Integer cartItemId){
    cartService.deleteItem(cartItemId);
    return "redirect:/cart";
  }
}
