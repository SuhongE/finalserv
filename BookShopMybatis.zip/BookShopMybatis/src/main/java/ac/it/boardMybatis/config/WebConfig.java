package ac.it.boardMybatis.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class WebConfig implements WebMvcConfigurer {

   // file.board.dir=H:/uploads/boards
   // file.book.dir=H:/uploads/books
    @Value("${file.board.dir}")
    private String uploadBoardDir;  // file.board.dir=H:/uploads/boards

    @Value("${file.book.dir}")
    private String uploadBookDir;  // file.book.dir=H:/uploads/books

     @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        registry.addResourceHandler("/boardfiles/**")
                .addResourceLocations("file:" + uploadBoardDir + "/");

        registry.addResourceHandler("/bookfiles/**")
                .addResourceLocations("file:" + uploadBookDir + "/");
    }
}

