package ac.it.boardMybatis.DTO;

import lombok.Data;

@Data
public class OrderItemView {
    private Long order_item_id;
    private Long book_id;
    private String title;
    private int price;
    private int qty;
    private int lineTotal;
}

