package ac.it.boardMybatis.controller;

import ac.it.boardMybatis.DTO.Book;
import ac.it.boardMybatis.DTO.MemberDTO;
import ac.it.boardMybatis.mapper.AdminBookMapper;
import ac.it.boardMybatis.service.BookService;
//import ac.it.boardMybatis.service.FileStorage;
import ac.it.boardMybatis.service.FileUploadService;
import jakarta.servlet.http.HttpSession;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;

@Controller
@RequiredArgsConstructor
@RequestMapping("/admin/books")
public class AdminBookController {
  private final AdminBookMapper adminBookMapper;
  private final BookService bookService;
//  private final FileStorage fileStorage;
  private final FileUploadService fileUploadService;

  private void requireAdmin(HttpSession session){
    MemberDTO m = (MemberDTO) session.getAttribute("loginUser");
    if(m == null || !"ADMIN".equals(m.getRole()))
        throw new RuntimeException("Admin only can access");
  }

  @GetMapping
  public String list(HttpSession s, Model model){
    requireAdmin(s);
    model.addAttribute("items", adminBookMapper.findAll());
    return "admin/books/list";
  }

  @GetMapping("/new")
  public String formNew(HttpSession s, Model model){
    requireAdmin(s);
    model.addAttribute("book", new Book());
    return "admin/books/form";
  }

  @PostMapping("/new")
  public String create(HttpSession s,
                       @ModelAttribute Book book,
                       @RequestParam(name="image", required=false) MultipartFile image){
    requireAdmin(s);
    String relPath = null;
    try {
          relPath = fileUploadService.storeImageAndGetUrl(image, "book");
    } catch (IOException e) {
          throw new RuntimeException(e);
    }
    if(relPath != null) book.setThumbnailPath(relPath);

    System.out.println("=========>/admin/books/new:"+ book.getTitle());
    System.out.println("=========>/admin/books/new:"+ book.getAuthor());
    System.out.println("=========>/admin/books/new:"+ book.getPublisher());
    System.out.println("=========>/admin/books/new:"+ book.getPrice());
    System.out.println("=========>/admin/books/new:"+ book.getStock());
    System.out.println("=========>/admin/books/new:"+ book.getThumbnailPath());
    System.out.println("=========>/admin/books/new:"+ book.getDescription());
    System.out.println("=========>/admin/books/new:"+ book.getRegDate());

    adminBookMapper.insert(book);
    return "redirect:/admin/books";
  }

  @GetMapping("/{id}/edit")
  public String editForm(HttpSession s, @PathVariable Integer id, Model model){
    requireAdmin(s);
    model.addAttribute("book", bookService.findById(id));
    return "admin/books/editform";
  }

  @PostMapping("/{id}")  // edit book
  public String update(HttpSession s, @PathVariable Integer id,
                       @ModelAttribute Book book,
                       @RequestParam(name="image", required=false) MultipartFile image){
    requireAdmin(s);
    System.out.println("==========> 기존책 수정");
    book.setId(id);

    if( !image.isEmpty() ) {  // new image
        String relPath = null;
        try {
            relPath = fileUploadService.storeImageAndGetUrl(image, "book");
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        if (relPath != null) book.setThumbnailPath(relPath);
    } else {  // not image update => Keep existing image name
        book.setThumbnailPath(book.getThumbnailPath()); // 기존이미지 주소 그대로 복귀
    }
    adminBookMapper.update(book);
    return "redirect:/admin/books";
  }

  @PostMapping("/{id}/delete")
  public String delete(HttpSession s, @PathVariable Integer id){
    requireAdmin(s);
    adminBookMapper.delete(id);
    return "redirect:/admin/books";
  }
}
