package ac.it.boardMybatis.DTO;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.util.List;

@Data
@AllArgsConstructor
public class OrderDetailView {
    private Order order;
    private List<OrderItemView> items;
    private int total;
}

