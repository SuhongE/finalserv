package ac.it.boardMybatis.DTO;
import lombok.Data;

@Data
public class CartItemView {
  private Integer cartItemId;
  private Integer bookId;
  private String title;
  private Integer price;
  private Integer qty;
  private Integer lineTotal;
}
