package ac.it.boardMybatis.mapper;

import ac.it.boardMybatis.DTO.Book;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface AdminBookMapper {
  void insert(@Param("b") Book b);
  void update(Book b);
  void delete(Integer id);
  List<Book> findAll();
}
