package ac.it.boardMybatis.service;

import ac.it.boardMybatis.DTO.Book;
import ac.it.boardMybatis.DTO.BookSearchCond;
import ac.it.boardMybatis.mapper.BookMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class BookService {
  private final BookMapper bookMapper;

  public Book findById(Integer id){
      return bookMapper.findById(id);
  }
  public int count(BookSearchCond cond){
      return bookMapper.count(cond);
  }
  public List<Book> findPage(BookSearchCond cond){
      return bookMapper.findPage(cond);
  }
  public Object findFeatured(int i) {
      return bookMapper.findFeatured(i);
  }
}
