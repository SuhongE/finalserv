package ac.it.boardMybatis.mapper;

import ac.it.boardMybatis.DTO.CartItemView;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface CartMapper {
  Integer findCartIdByMemberId(Integer memberId);
  void createCart(Integer memberId);
  void upsertCartItem(Integer cartId, Integer bookId, Integer qty);
  List<CartItemView> findCartItems(Integer cartId);
  void updateQty(Integer cartItemId, Integer qty);
  void deleteItem(Integer cartItemId);
  void clearCart(Integer cartId);

  // cartId로 cart_item count 조회
  int countItems(@Param("cartId") Integer cartId);
}
