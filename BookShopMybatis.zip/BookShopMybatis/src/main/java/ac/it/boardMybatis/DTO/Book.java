package ac.it.boardMybatis.DTO;
import lombok.Data;

@Data
public class Book {
  private Integer id;
  private String title;
  private String author;
  private String publisher;
  private Integer price;
  private Integer stock;
  private Integer categoryId;
  private String thumbnailPath;
  private String description;
  private String regDate;
}
