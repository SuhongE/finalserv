package ac.it.boardMybatis.service;

import ac.it.boardMybatis.DTO.CartItemView;
import ac.it.boardMybatis.mapper.CartMapper;
import ac.it.boardMybatis.mapper.CartMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service @RequiredArgsConstructor
public class CartService {
  private final CartMapper cartMapper;

  private Integer ensureCart(Integer memberId){
    Integer cartId = cartMapper.findCartIdByMemberId(memberId);
    if(cartId == null){ cartMapper.createCart(memberId); cartId = cartMapper.findCartIdByMemberId(memberId); }
    return cartId;
  }

  @Transactional
  public void addItem(Integer memberId, Integer bookId, Integer qty){
    Integer cartId = ensureCart(memberId);
    cartMapper.upsertCartItem(cartId, bookId, qty);
  }

  public List<CartItemView> listItems(Integer memberId){
    Integer cartId = cartMapper.findCartIdByMemberId(memberId);
    if(cartId == null) return List.of();
    return cartMapper.findCartItems(cartId);
  }

  public void updateQty(Integer cartItemId, Integer qty){ cartMapper.updateQty(cartItemId, qty); }
  public void deleteItem(Integer cartItemId){ cartMapper.deleteItem(cartItemId); }

  public void clear(Integer memberId){
    Integer cartId = cartMapper.findCartIdByMemberId(memberId);
    if(cartId != null) cartMapper.clearCart(cartId);
  }

  public int getCartItemCount(int memberId) {
        Integer cartId = cartMapper.findCartIdByMemberId(memberId);
        if (cartId == null) return 0;
        return cartMapper.countItems(cartId);
  }
}
