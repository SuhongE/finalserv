package ac.it.boardMybatis.DTO;
import lombok.Data;

import java.time.LocalDateTime;

@Data
public class Order {
  private Long id;
  private Integer member_id;
  private Integer total_price;
  private String order_status;
//  private String createdAt;
  private LocalDateTime created_at;
}
