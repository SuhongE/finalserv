package ac.it.boardMybatis.controller;

import ac.it.boardMybatis.DTO.MemberDTO;
import ac.it.boardMybatis.DTO.Order;
import ac.it.boardMybatis.DTO.OrderDetailView;
import ac.it.boardMybatis.service.OrderService;
import jakarta.servlet.http.HttpSession;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;

@Controller @RequiredArgsConstructor
@RequestMapping("/orders")
public class OrderController {
  private final OrderService orderService;

    @GetMapping
    public String list(HttpSession session, Model model) {
        MemberDTO loginMember = (MemberDTO) session.getAttribute("loginUser");
        if (loginMember == null) {
            // 로그인 안 했으면 로그인 페이지로
            return "redirect:/auth/login";
        }

        List<Order> orders = orderService.findByMemberId(loginMember.getId());
        model.addAttribute("orders", orders);
        return "orders/list"; // templates/orders/list.html
    }

  @PostMapping
  public String create(HttpSession session){
    MemberDTO m = (MemberDTO) session.getAttribute("loginUser");
    Long orderId = orderService.checkout(m.getId());
    return "redirect:/orders/" + orderId;
  }

  @GetMapping("/{id}")
  public String detail(@PathVariable Long id, Model model, HttpSession session){
    MemberDTO loginMember = (MemberDTO)session.getAttribute("loginUser");
    OrderDetailView orderDetail = orderService.getOrderDetail(loginMember.getId(), id);

    model.addAttribute("detail", orderDetail);
    model.addAttribute("order", orderDetail.getOrder());
    model.addAttribute("items", orderDetail.getItems());
    model.addAttribute("sum", orderDetail.getTotal());
    return "orders/detail";
  }
}
