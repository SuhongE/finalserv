package ac.it.boardMybatis.config;

import ac.it.boardMybatis.DTO.MemberDTO;
import ac.it.boardMybatis.service.CartService;
import jakarta.servlet.http.HttpSession;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ModelAttribute;

@ControllerAdvice  // 모든 컨트롤러 실행 전에 cartItemCount 라는 이름의 모델 값이 자동으로 추가됩니다.
@RequiredArgsConstructor
public class GlobalModelAttributes {

    private final CartService cartService;

    //    로그인 안 된 경우 → 0
    //    로그인 된 경우 → 그 회원의 장바구니 수량

    @ModelAttribute("cartItemCount")
    public Integer cartCount(HttpSession session) {
        MemberDTO loginMember = (MemberDTO) session.getAttribute("loginUser");
        if (loginMember == null) {
            System.out.println("cartItemCount:NotLogined => 0");
            return 0;
        }
        System.out.println("cartItemCount:"+loginMember.getEmail());
        return cartService.getCartItemCount(loginMember.getId());
    }
}

