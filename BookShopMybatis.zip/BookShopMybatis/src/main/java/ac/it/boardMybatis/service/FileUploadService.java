package ac.it.boardMybatis.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.util.UUID;

@Service
public class FileUploadService {

    @Value("${file.board.dir}")  // board image save
    private String uploadBoardDir;  // file.board.dir=H:/uploads/boards

    @Value("${file.book.dir}")  // book image save
    private String uploadBookDir;  // file.book.dir=H:/uploads/books

    private String uploadDir=null;

    public String storeImageAndGetUrl(MultipartFile image, String tag) throws IOException {
        if(tag.equals("book")) {
            uploadDir = uploadBookDir;
        } else {
            uploadDir = uploadBoardDir;
        }
        // 1. image file Validation
        valdidateImage(image);
        // 2. create saved file path & file name
        LocalDate now = LocalDate.now();
        Path dir = Paths.get(uploadDir, String.valueOf(now.getYear()), String.format("%02d", now.getMonthValue()));
        Files.createDirectories(dir);
        String orginalFileName = image.getOriginalFilename();
        String storedFileName = createStoredFileName(orginalFileName);
        // 3. savd file
        Path target = dir.resolve(storedFileName);
        image.transferTo(target.toFile());
        // 4. return file path
        String urlPath;
        if(tag.equals("book")) {
            urlPath = "/bookfiles/" + now.getYear() + "/" + String.format("%2d", now.getMonthValue()) + "/" + storedFileName;
        } else {
            urlPath = "/boardfiles/" + now.getYear() + "/" + String.format("%2d", now.getMonthValue()) + "/" + storedFileName;
        }
     //   String urlPath = "/files/" + now.getYear() + "/" + String.format("%2d", now.getMonthValue()) + "/" + storedFileName;
        return urlPath;
    }

    public String createStoredFileName(String originalFilename) {
        String ext = "";
        if (originalFilename != null && originalFilename.contains(".")) {
            ext = originalFilename.substring(originalFilename.lastIndexOf("."));
        }
        return UUID.randomUUID().toString().replace("-", "") + ext;
    }

    public void valdidateImage(MultipartFile image) {
        if(image.getSize() > 10 * 1024 * 1024) { // check image size 10MB
            throw new IllegalArgumentException("image size error");
        }
    }
 }
