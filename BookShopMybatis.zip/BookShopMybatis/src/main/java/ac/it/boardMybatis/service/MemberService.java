package ac.it.boardMybatis.service;

import ac.it.boardMybatis.DTO.MemberDTO;
import ac.it.boardMybatis.mapper.MemberMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service // make a object from this class and store it to Spring-container
public class MemberService {

    @Autowired
    MemberMapper memberMapper;

    public void registNewMember(MemberDTO dto) {
       dto.setRole("USER"); // general user must be "USER"
        memberMapper.insertMember(dto);
    }

    public MemberDTO login(MemberDTO memberDTO) {
        MemberDTO member = memberMapper.findUser(memberDTO);
        return member;
    }

    public List<MemberDTO> getAllmembers() {
        List<MemberDTO> list = memberMapper.getAllMembers();
        return list;
    }

    public MemberDTO findById(int id) {
        MemberDTO member = memberMapper.findById(id);
        return member;
    }

    public void updateMember(MemberDTO dto) {
        memberMapper.updateMember(dto);
    }

    public void deleteMember(int id) {
        memberMapper.deleteMember(id);
    }
}
