package ac.it.boardMybatis.DTO;
import lombok.Data;

@Data
public class BookSearchCond {
  private String keyword;
  private Integer categoryId;
  private Integer minPrice;
  private Integer maxPrice;
  private Integer page = 1;
  private Integer size = 12;

    public int getOffset() { // <-- MyBatis가 찾는 getter
        int p = (page == null || page < 1) ? 1 : page;
        int s = (size == null || size < 1) ? 12 : size;
        return (p - 1) * s;
    }
}
