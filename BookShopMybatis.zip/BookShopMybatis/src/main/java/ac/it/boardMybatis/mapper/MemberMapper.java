package ac.it.boardMybatis.mapper;

import ac.it.boardMybatis.DTO.MemberDTO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

// Instead of MemberDAO
@Mapper
public interface MemberMapper {
    public void insertMember(@Param("dto") MemberDTO dto);
    public MemberDTO findUser(@Param("dto") MemberDTO dto);
    public List<MemberDTO> getAllMembers();
    public MemberDTO findById(@Param("id") int id);
    public void updateMember(@Param("dto") MemberDTO dto);
    public void deleteMember(@Param("id") int id);
}
