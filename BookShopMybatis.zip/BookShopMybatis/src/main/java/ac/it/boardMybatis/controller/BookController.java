package ac.it.boardMybatis.controller;

import ac.it.boardMybatis.DTO.BookSearchCond;
import ac.it.boardMybatis.service.BookService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller @RequiredArgsConstructor
@RequestMapping("/books")
public class BookController {
  private final BookService bookService;

  @GetMapping
  public String list(@ModelAttribute("cond") BookSearchCond cond, Model model){
    System.out.println("/books"+cond.getKeyword());
    System.out.println("/books"+cond.getOffset());
    var total = bookService.count(cond);
    var items = bookService.findPage(cond);
    model.addAttribute("items", items);
    model.addAttribute("total", total);
    model.addAttribute("page", cond.getPage());
    model.addAttribute("size", cond.getSize());
    return "books/list";
  }

  @GetMapping("/{id}")
  public String detail(@PathVariable Integer id, Model model){
    model.addAttribute("b", bookService.findById(id));
    return "books/detail";
  }
}
