package ac.it.boardMybatis.mapper;

import ac.it.boardMybatis.DTO.Book;
import ac.it.boardMybatis.DTO.BookSearchCond;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface BookMapper {
  Book findById(Integer id);
  int count(BookSearchCond cond);
  List<Book> findPage(BookSearchCond cond);

  List<Book> findFeatured(int i);
}
