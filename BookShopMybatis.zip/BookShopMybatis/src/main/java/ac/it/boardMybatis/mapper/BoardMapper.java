package ac.it.boardMybatis.mapper;

import ac.it.boardMybatis.DTO.BoardDTO;
import ac.it.boardMybatis.DTO.MemberDTO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

// Instead of MemberDAO
@Mapper
public interface BoardMapper {
    public List<BoardDTO> getAllBoardList();
    public void insertBoard(@Param("board") BoardDTO board);
    public BoardDTO getBoardById(@Param("id") int id);
    public void increaseView(@Param("id") int id);
    public void deleteBoard(@Param("id") int id);
}
