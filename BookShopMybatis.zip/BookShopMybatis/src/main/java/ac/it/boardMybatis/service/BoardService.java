package ac.it.boardMybatis.service;

import ac.it.boardMybatis.DTO.BoardDTO;
import ac.it.boardMybatis.mapper.BoardMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;

@Service
public class BoardService {

    @Autowired  BoardMapper boardMapper;
    @Autowired  FileUploadService fileUploadService;

    public List<BoardDTO> getBoardAll() {
        List<BoardDTO> list = boardMapper.getAllBoardList();
        return list;
    }

    public void insertBoard(BoardDTO newBoard, MultipartFile image) {
        // boardMapper.insertBoard(newBoard);
        //try to save image
        if(image != null && !image.isEmpty()) {
            try {
                String urlPath = fileUploadService.storeImageAndGetUrl(image, "board");
                newBoard.setImage_path(urlPath);
                newBoard.setImage_original_name(image.getOriginalFilename());
                boardMapper.insertBoard(newBoard);
            } catch (IOException e) {
                System.out.println(e.getMessage());
            }
        }
    }

    public BoardDTO getBoardById(int id) {
        // try to increase views
        boardMapper.increaseView(id);

        BoardDTO boardDTO = boardMapper.getBoardById(id);
        return boardDTO;
    }

    public void boardDelete(int id) {
        boardMapper.deleteBoard(id);
    }
}
