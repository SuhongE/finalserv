package ac.it.boardMybatis.service;

import ac.it.boardMybatis.DTO.CartItemView;
import ac.it.boardMybatis.DTO.Order;
import ac.it.boardMybatis.DTO.OrderDetailView;
import ac.it.boardMybatis.DTO.OrderItemView;
import ac.it.boardMybatis.mapper.CartMapper;
import ac.it.boardMybatis.mapper.OrderMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
public class OrderService {
  private final OrderMapper orderMapper;
  private final CartMapper cartMapper;

  @Transactional
  public Long checkout(Integer memberId){
    // checkout 시
    // 1. cart_item : 해당 상품 삭제
        //  1-1 로긴한 사람의 cart 번호 찾고
        //  1-2 cart 번호 => cart_item 에서 상품 다 찾음 => 전체 총액 구함
    // 2. book table 재고 감소
    // 3. Order - Order_item 생성
    // 4. cart_item 에서 해당상품 삭제

    Integer cartId = cartMapper.findCartIdByMemberId(memberId);
    if(cartId == null) throw new IllegalStateException("장바구니가 비어있습니다.");

    List<CartItemView> items = cartMapper.findCartItems(cartId);
    if(items.isEmpty()) throw new IllegalStateException("장바구니가 비어있습니다.");

    //int total = items.stream().mapToInt(CartItemView::getLineTotal).sum();
    int total = 0;
    for (CartItemView item : items) {
          total += item.getLineTotal();
    }
    // total 변수에 최종 합계가 저장됩니다.

    for(var it : items){
      int updated = orderMapper.decreaseStock(it.getBookId(), it.getQty()); // book 재고 감소시킴
      if(updated == 0) throw new IllegalStateException("재고 부족: " + it.getTitle());
    }

    // order 테이블에 기록
    Order order = new Order();
    order.setMember_id(memberId);
    order.setTotal_price(total);
    order.setOrder_status("PAID");
    orderMapper.insertOrder(order);  // 저장하면 id가 자동 생성되는데, 이것이 여기 객체에 자동 전달됨

    for(var it : items){ // order_item table에 기록
      orderMapper.insertOrderItem(order.getId(), it.getBookId(), it.getPrice(), it.getQty());
    }

    cartMapper.clearCart(cartId); // cart_item에서 해당 cartId 삭제,
    return order.getId();
  }

    public List<Order> findByMemberId(Integer memberId) {
      return orderMapper.findByMemberId(memberId);
    }

    public Order findDetail(Integer orderId, Integer memberId)
    {
        return orderMapper.findDetail(orderId, memberId);
    }

    public OrderDetailView getOrderDetail(int memberId, Long orderId) {
      System.out.println("OrderServerce : getOrderDetail() memberId, orderId=>" + memberId + ":" + orderId);
      Order order = orderMapper.findOrder(memberId, orderId);
      if(order == null) {
          throw new IllegalStateException("Order not found or access denied");
      }

      List<OrderItemView> items = orderMapper.findOrderItems(orderId);

      int total = items.stream()
                .mapToInt(OrderItemView::getLineTotal)
                .sum();

       return new OrderDetailView(order, items, total);
    }
}
