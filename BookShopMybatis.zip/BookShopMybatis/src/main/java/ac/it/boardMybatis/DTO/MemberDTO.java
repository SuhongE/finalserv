package ac.it.boardMybatis.DTO;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class MemberDTO {
    private int id;
    private String email;
    private String pwd;
    private int age;
    private String role;
}
