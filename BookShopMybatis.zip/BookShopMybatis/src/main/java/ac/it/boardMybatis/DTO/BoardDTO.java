package ac.it.boardMybatis.DTO;

import lombok.*;

import java.sql.Timestamp;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class BoardDTO {
    private int id;
    private String title;
    private int member_id;
    private String content;
    private Timestamp regDate;
    private int views;
    private String writer_email;

    private String image_path;
    private String image_original_name;
}
