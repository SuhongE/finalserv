package ac.it.boardMybatis.controller;

import ac.it.boardMybatis.DTO.BoardDTO;
import ac.it.boardMybatis.DTO.MemberDTO;
import ac.it.boardMybatis.service.BoardService;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@Controller
public class BoardController {
    @Autowired
    BoardService boardService;

    @GetMapping("/boardList")
    public String boardList(Model model) {
        List<BoardDTO> list = boardService.getBoardAll();
        model.addAttribute("list", list);
        return "boardList"; // boardList.html
    }

    @GetMapping("/boardWrite")
    public String boardWrite() {
        return "boardWrite"; // boardWrite.html
    }

    @PostMapping("/boardWrite")
    public String boardWriteToDB(@RequestParam(value = "image") MultipartFile image,
                                 BoardDTO newBoard, HttpSession session) {
        // find login User id
        MemberDTO loginedUser = (MemberDTO)session.getAttribute("loginUser");
        int loginedId = loginedUser.getId();
        newBoard.setMember_id(loginedId);

        boardService.insertBoard(newBoard, image);

        return "redirect:boardList";
    }

    @GetMapping("/boardDetail")
    public String boardDetail(@RequestParam("id") int id, Model model) {
        BoardDTO boardDTO = boardService.getBoardById(id);
        model.addAttribute("board", boardDTO);
        return "boardDetail";
    }

    @GetMapping("/boardDelete/{id}")
    public String boardDelete(@PathVariable("id") int id) {
        System.out.println("boardId:"+id);
        boardService.boardDelete(id);
        return "redirect:/boardList";
    }
}
